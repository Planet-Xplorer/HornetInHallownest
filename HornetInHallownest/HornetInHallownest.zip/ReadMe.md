# Hornet in Hallownest!

This is my repo for a mod that will ideally allow for the user to play as Hornet from Silksong in Hollow Knight.

The main goal for this is so that the player can use their tools, silk skills, etc. when being as hornet. Hornet should be spawning in with all her movement abilities unlocked, following the precedent by the "Knight in Silksong" mod, which did the same thing, since I presume it'll be irritating to also add progression, and generally most people using this mod just want to fight all the bosses in hollow knight as hornet anyway.

# Configuration at this moment:
Per-machine setup (one time only):

**Linux** — add to `~/.bashrc`, then restart your terminal:
```bash
export HK_REFS="/path/to/Hollow Knight_Data/Managed/"
export HK_EXPORT="/path/to/any/folder/you/want/"
```

**Windows** — paste into PowerShell and run, then restart your terminal before building:
```powershell
[System.Environment]::SetEnvironmentVariable("HK_REFS", "C:\path\to\hollow_knight_Data\Managed\", "User")
[System.Environment]::SetEnvironmentVariable("HK_EXPORT", "C:\path\to\any\folder\you\want\", "User")
```

Then build with:
```bash
dotnet build MyHornetMod.csproj
```

# Shout Outs
Thanks to the people at Lumafly for helping provide the template and some resources.

Thanks to the whole hollow knight community for being cool (and for not making this mod before I was inspired to and stealing my thunder ya'll are real for that).

Most of all, thanks to team cherry for making two awesome games in a row, and inspiring me to make this mod in the first place.
